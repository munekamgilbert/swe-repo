package edu.mum.cs.cs425.studentmgmt.repository;


import org.springframework.stereotype.Repository;

@Repository
public interface TranscriptRepository {

}
